const BASE_URL = "https://jsonplaceholder.typicode.com/posts";

export const postHttp = async (sec) => {
  const data = { seconds: sec };

  try {
    const response = await fetch(BASE_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const jsonData = await response.json();
    return jsonData;
  } catch (error) {
    console.log(error);
  }
};
