import { postHttp } from "./postHttp";

export const saveSeconds = async (sec) => {
  const data = await postHttp(sec);
  return data;
};
