import { saveSeconds } from "./saveSecond";

const requestedEntries = [];
const resolvedEntries = [];
let hidden;
let visibilityChange;
let requestedEntriesCache;
const button = document.getElementById("btn");

if (typeof document.hidden !== "undefined") {
  hidden = "hidden";
  visibilityChange = "visibilitychange";
} else if (typeof document.msHidden !== "undefined") {
  hidden = "msHidden";
  visibilityChange = "msvisibilitychange";
} else if (typeof document.webkitHidden !== "undefined") {
  hidden = "webkitHidden";
  visibilityChange = "webkitvisibilitychange";
}

const printData = async (sec) => {
  const data = await saveSeconds(sec);
  if (data) {
    console.log(`id:${data.id}, second:${sec}`);
  }
};

const handleClick = async () => {
  const sec = new Date().getSeconds();
  if (requestedEntries.includes(sec)) {
    console.log(`already requested for ${sec}`);
  } else {
    requestedEntries.push(sec);
    printData(sec);
  }
};

document.addEventListener(
  visibilityChange,
  () => {
    if (document[hidden]) {
      requestedEntriesCache = requestedEntries;
    } else {
      const requestedEntries = requestedEntriesCache.splice(
        resolvedEntries.length,
        requestedEntriesCache.length
      );

      requestedEntries.forEach(async (entry) => {
        printData(entry);
      });
    }
  },
  false
);

button.addEventListener("click", handleClick);
